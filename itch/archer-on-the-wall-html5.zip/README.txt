Archer on the Wall — full version / 城头射手 正式版

How to play / 怎么玩
1. Unzip the whole folder. / 把整个压缩包解压到一个文件夹。
2. Double-click index.html (Chrome, Edge or Firefox). / 用 Chrome、Edge 或 Firefox 双击打开 index.html。
3. No installation, no internet needed. / 不用安装，也不需要联网。

Your save lives in the browser. Use Settings > Export save to back it up. / 存档保存在浏览器里，建议在「设置」里定期「导出存档」备份。

Feedback / 反馈: https://linshangsheng.itch.io/archer-on-the-wall
Credits / 致谢: see CREDITS.md
